import React, { Component } from "react";
import { Navbar, Nav } from "react-bootstrap";
import { Link } from "react-router-dom";

class Ipfs extends Component {
  render(){
    return();
  }
}

export default Ipfs;
